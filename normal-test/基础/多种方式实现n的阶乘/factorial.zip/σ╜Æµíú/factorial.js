// "use strict";
// var test = 10;
/**
 * 方法1：递归
 * @param {number} n
 */
function factorial_1(n) {
  if (n == 1) return 1;
  return n * factorial_1(n - 1);
}
// console.time("方法1");
// console.log("方法1", factorial_1(test));
// console.timeEnd("方法1");

/**
 * 方法2：尾递归优化
 * @param {number} n
 * @param {number} t
 */
function factorial_2(n, t) {
  if (n == 1) return t;
  return factorial_2(n - 1, n * t);
}
// console.time("方法2");
// console.log("方法2", factorial_2(test, 1));
// console.timeEnd("方法2");

/**
 * 方法3：while循环
 * @param {number} n
 */
function factorial_3(n) {
  var r = 1;
  while (n > 0) {
    r *= n--;
  }
  return r;
}
// console.time("方法3");
// console.log("方法3", factorial_3(test));
// console.timeEnd("方法3");

/**
 * 大数相乘算法
 * @param {string} num1
 * @param {string} num2
 */
function bcmul(num1, num2) {
  return (BigInt(num1) * BigInt(num2)).toString();
}
/**
 * 方法4：大数阶乘
 * @param {number} n
 */
function factorial_4(n) {
  var r = 1;
  while (n > 0) {
    r = bcmul((n--).toString(), r.toString());
  }
  return r;
}
// console.time("方法4");
// console.log("方法4", factorial_4(test));
// console.timeEnd("方法4");

/**
 * 方法5：阶乘优化
 * @param {number} n
 */
function factorial_5(n) {
  var middleSquare = Math.pow(Math.floor(n / 2), 2);
  var result = (n & 1) == 1 ? 2 * middleSquare * n : 2 * middleSquare;
  result = result.toString();
  for (var num = 1; num < n - 2; num = num + 2) {
    middleSquare = middleSquare - num;
    result = bcmul(result, middleSquare.toString());
  }
  return result;
}
// console.time("方法5");
// console.log("方法5", factorial_5(test));
// console.timeEnd("方法5");

module.exports = {
  factorial_1,
  factorial_2,
  factorial_3,
  factorial_4,
  factorial_5
};
